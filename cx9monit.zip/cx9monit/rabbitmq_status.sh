#!/bin/bash
rabbitmq-diagnostics ping -q
