#!/bin/bash

status=active
command=$(systemctl status intellilogpub | grep active | awk '{print $2}')

if [ $command == $status ]; then
exit 0
else
exit 1
fi
